package com.murach.invoice;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Activity;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import java.text.NumberFormat;

public class InvoiceTotalActivity extends Activity implements TextView.OnEditorActionListener {

	private EditText subTotalEditText;
	private TextView discountPercentTextView;
	private TextView discountAmountTextView;
	private TextView totalTextView;

	private SharedPreferences savedValues;

	private String subtotalString = "";
	private float discountPercent = 0.0f;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_invoice_total);

		subTotalEditText = (EditText) findViewById(R.id.subtotalEditText);
		discountPercentTextView = (TextView) findViewById(R.id.discountPercentTextView);
		discountAmountTextView = (TextView) findViewById(R.id.discountAmountTextView);
		totalTextView = (TextView) findViewById(R.id.totalTextView);

		subTotalEditText.setOnEditorActionListener(this);

		savedValues = getSharedPreferences("SavedValues", MODE_PRIVATE);

	}

	@Override
	public void onResume(){
		super.onResume();

		String subtotalString = savedValues.getString("subtotalString", "");
		discountPercent = savedValues.getFloat("discountPercent", 0.0f);

		subTotalEditText.setText(subtotalString);

		calculateAndDisplay();
	}

	public void calculateAndDisplay() {
		int subtotal;
		subtotalString = subTotalEditText.getText().toString();
		if(subtotalString.equals("")){
			subtotal = 0;
		}
		else{
			subtotal = Integer.parseInt(subtotalString);
		}
		double discount = 0.00;

		if (subtotal >= 200) {
			discount = .20;
		} else if (subtotal >= 100)
			discount = .10;

		double discountAmount = (subtotal * discount);
		double total = subtotal - discountAmount;

		NumberFormat discountPercent = NumberFormat.getPercentInstance();
		NumberFormat currency = NumberFormat.getCurrencyInstance();

		String discountAmountString = currency.format(discountAmount);
		String totalString = currency.format(total);

		discountAmountTextView.setText(discountAmountString);
		totalTextView.setText(totalString);
		discountPercentTextView.setText(discountPercent.format(discount));
	}

	@Override
	public boolean onEditorAction(TextView textView, int action_id, KeyEvent keyEvent) {
		if (action_id == EditorInfo.IME_ACTION_DONE) {
			calculateAndDisplay();
		}
		return false;
	}

	@Override
	public void onPause() {
		SharedPreferences.Editor editor = savedValues.edit();
		editor.putString("subtotalString", subtotalString);
		editor.putFloat("discountPercent", discountPercent);
		editor.commit();
		super.onPause();
	}
}