package com.example.assignment_4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.app.Activity;
import android.view.inputmethod.EditorInfo;


import com.google.android.material.navigation.NavigationBarView;

import org.w3c.dom.Text;

import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity
        implements TextView.OnEditorActionListener, AdapterView.OnItemSelectedListener {

    private Spinner selectSpinner;
    private TextView unit, convertedTo, convertedToView;
    private EditText conversionEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        unit = (TextView) findViewById(R.id.Unit);
        convertedTo = (TextView) findViewById(R.id.ConvertedTo);
        convertedToView = (TextView) findViewById(R.id.convertedToText);
        conversionEditText = (EditText) findViewById(R.id.conversionEdit);

        selectSpinner = (Spinner) findViewById(R.id.spinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.split_array, android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        selectSpinner.setAdapter(adapter);

        conversionEditText.setOnEditorActionListener(this);
        selectSpinner.setOnItemSelectedListener(this);
    }


    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_UNSPECIFIED) {
            calculateAndDisplay();
        }
        return false;
    }

    public void calculateAndDisplay() {
        int baseUnits;
        double conversion;
        String convertedString;

        String toConvert = conversionEditText.getText().toString();

        if (toConvert.equals("")) {
            baseUnits = 0;
        } else {
            baseUnits = Integer.parseInt(toConvert);
        }

        int position = selectSpinner.getSelectedItemPosition();

        switch (position) {
            case 0:
                conversion = baseUnits * 1.6093;
                convertedString = String.valueOf(roundTwoDecimals(conversion));
                convertedToView.setText(convertedString);
                break;
            case 1:
                conversion = baseUnits * .6214;
                convertedString = String.valueOf(roundTwoDecimals(conversion));
                convertedToView.setText(convertedString);
                break;
            case 2:
                conversion = baseUnits * 2.54;
                convertedString = String.valueOf(roundTwoDecimals(conversion));
                convertedToView.setText(convertedString);
                break;
            case 3:
                conversion = baseUnits * .3937;
                convertedString = String.valueOf(roundTwoDecimals(conversion));
                convertedToView.setText(convertedString);
                break;
            default:
                break;
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        int item = adapterView.getSelectedItemPosition();

        switch(item){
            case 0:
                unit.setText("Kilometers");
                convertedTo.setText("Miles");
                break;
            case 1:
                unit.setText("Miles");
                convertedTo.setText("Kilometers");
                break;
            case 2:
                unit.setText("Inches");
                convertedTo.setText("Centimeters");
                break;
            case 3:
                unit.setText("Centimeters");
                convertedTo.setText("Inches");
                break;
        }
        calculateAndDisplay();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        calculateAndDisplay();
    }

    public double roundTwoDecimals(double d){
        DecimalFormat twoForm = new DecimalFormat("#.##");
        return Double.valueOf(twoForm.format(d));
    }

}


