package com.murach.tipcalculator;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceFragment;

public class SettingsFragment extends PreferenceFragment
        implements SharedPreferences.OnSharedPreferenceChangeListener {

    private SharedPreferences prefs;
    private boolean rememberPercent;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Load the preferences from an XML resource
        addPreferencesFromResource(R.xml.preferences);
    }


    @Override
    public void onResume() {
        super.onResume();
        rememberPercent = prefs.getBoolean("pref_remember_percent", true);
        this.setDefaultPercentPreference(rememberPercent);
        prefs.registerOnSharedPreferenceChangeListener(this);
    }

    private void setDefaultPercentPreference(boolean rememberPercent) {
        Preference defaultPercent = findPreference("pref_default_percent");
        if(rememberPercent){
            defaultPercent.setEnabled(false);
        }
        else{
            defaultPercent.setEnabled(true);
        }
    }

    @Override
    public void onPause()
    {
        prefs.unregisterOnSharedPreferenceChangeListener(this);
        super.onPause();
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String s) {
        if(s.equals("pref_remember_percent")){
            rememberPercent=prefs.getBoolean(s, true);
        }
        this.setDefaultPercentPreference(rememberPercent);
    }
}